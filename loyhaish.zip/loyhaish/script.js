function showAlert() {
  alert("Bu loyiha haqida batafsil ma'lumot yaqin orada qo‘shiladi.");
}
